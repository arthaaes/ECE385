module carry_select_adder
(
    input   logic[15:0]     A,
    input   logic[15:0]     B,
    output  logic[15:0]     Sum,
    output  logic           CO
);

    /* TODO
     *
     * Insert code here to implement a carry select.
     * Your code should be completly combinational (don't use always_ff or always_latch).
     * Feel free to create sub-modules or other files. */
	  
	 logic C4, C8, C12;
	 
	full_adder_four_bit     FA4B(.a (A[3 : 0]), .b (B[3 : 0]), .cin(1'b0), .sum(Sum[3 : 0]),  .cout(C4));
	carry_select_adder_4bit CSA1(.A4(A[7 : 4]), .B4(B[7 : 4]), .c_in(C4),  .sum(Sum[7 : 4]),  .cout(C8));
	carry_select_adder_4bit CSA2(.A4(A[11: 8]), .B4(B[11: 8]), .c_in(C8),  .sum(Sum[11: 8]),  .cout(C12));
	carry_select_adder_4bit CSA3(.A4(A[15:12]), .B4(B[15:12]), .c_in(C12),  .sum(Sum[15:12]),  .cout(CO));	
	 
     
endmodule

module multiplexor(
	input logic L0, L1,
	input logic Y,
	output logic OUT
);

	always_comb
	begin
		if (Y == 1'b1)
			OUT = L1;
		else           
			OUT = L0;
	end
	
endmodule


module carry_select_adder_4bit(
	input logic [3:0] A4,
	input logic [3:0] B4,
	input logic c_in,
	output logic [3:0] sum,
	output logic cout
 );
 
	logic [3:0] sum0, sum1;
	logic cout0, cout1;
	
	full_adder_four_bit FA4B0(.a(A4), .b(B4), .cin(1'b0), .sum(sum0),  .cout(cout0));
	full_adder_four_bit FA4B1(.a(A4), .b(B4), .cin(1'b1), .sum(sum1),  .cout(cout1));
	
	multiplexor MUX0(.L0(sum0[0]), .L1(sum1[0]), .Y(c_in), .OUT(sum[0]));
	multiplexor MUX1(.L0(sum0[1]), .L1(sum1[1]), .Y(c_in), .OUT(sum[1]));
	multiplexor MUX2(.L0(sum0[2]), .L1(sum1[2]), .Y(c_in), .OUT(sum[2]));
	multiplexor MUX3(.L0(sum0[3]), .L1(sum1[3]), .Y(c_in), .OUT(sum[3]));
	
	multiplexor MUXOUT(.L0(cout0), .L1(cout1), .Y(c_in), .OUT(cout));
 
 
endmodule
